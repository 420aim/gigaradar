import tokenInspect from "./src/plugins/token-inspect";

export default {
  plugins: [tokenInspect],
};

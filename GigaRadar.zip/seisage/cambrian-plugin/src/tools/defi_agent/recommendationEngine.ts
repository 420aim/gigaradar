import { RiskLevel } from './riskProfileManager';

type TokenData = {
  priceChange1h: number;
  priceChange24h: number; 
  volume24h: number; 
};

type Recommendation = 'BUY' | 'HOLD' | 'SELL';

export function getRecommendation(
  risk: RiskLevel,
  data: TokenData
): Recommendation {
  const { priceChange1h, priceChange24h, volume24h } = data;

  if (risk === 'high') {
    if (priceChange1h > 5 || priceChange24h > 10) return 'BUY';
    if (priceChange24h < -10) return 'SELL';
    return 'HOLD';
  }

  if (risk === 'medium') {
    if (priceChange24h > 5 && volume24h > 10000) return 'BUY';
    if (priceChange24h < -5) return 'SELL';
    return 'HOLD';
  }

  if (risk === 'low') {
    if (priceChange24h > 10 && volume24h > 20000) return 'BUY';
    if (priceChange24h < -3) return 'SELL';
    return 'HOLD';
  }

  return 'HOLD'; // fallback
}

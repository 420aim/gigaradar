import fs from 'fs';
import path from 'path';

const DATA_PATH = path.join(__dirname, '../../state/user_risk_profiles.json');

type RiskLevel = 'low' | 'medium' | 'high';

function ensureDataFile() {
  if (!fs.existsSync(DATA_PATH)) {
    fs.mkdirSync(path.dirname(DATA_PATH), { recursive: true });
    fs.writeFileSync(DATA_PATH, '{}');
  }
}

export function setUserRiskProfile(userId: number, risk: RiskLevel): boolean {
  try {
    ensureDataFile();
    const data = readRiskProfiles();
    data[userId] = risk;
    fs.writeFileSync(DATA_PATH, JSON.stringify(data, null, 2));
    return true;
  } catch (e) {
    console.error('[RISK-PROFILE] Error saving profile:', e);
    return false;
  }
}

export function getUserRiskProfile(userId: number): RiskLevel | null {
  try {
    ensureDataFile();
    const data = readRiskProfiles();
    return data[userId] || null;
  } catch (e) {
    console.error('[RISK-PROFILE] Error reading profile:', e);
    return null;
  }
}

function readRiskProfiles(): Record<number, RiskLevel> {
  try {
    const raw = fs.readFileSync(DATA_PATH, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

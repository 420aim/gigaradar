export * from "./dragonswap";
export interface Config {
  OPENAI_API_KEY?: string;
  PRIORITY_LEVEL?: "medium" | "high" | "veryHigh";
}

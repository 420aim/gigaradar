import { SeiAgentKit } from "../src/agent/index";
import * as dotenv from "dotenv";
import { analyzeToken } from "../src/tools/tokenAnalyzer/tokenAnalyzer";
import { Address } from "viem";

dotenv.config();

const SEIYAN_CONTRACT_ADDRESS: Address = '0x5f0E07dFeE5832Faa00c63F2D33A0D79150E8598';

async function main() {
  console.log("🔥 Menyiapkan SEI-Sage Agent...");

  if (!process.env.SEI_PRIVATE_KEY || !process.env.GEMINI_API_KEY) {
    console.error("❌ ERROR: Pastikan SEI_PRIVATE_KEY dan GEMINI_API_KEY sudah diisi di file .env");
    process.exit(1);
  }

  const privateKey = process.env.SEI_PRIVATE_KEY;
  if (privateKey.length !== 64) {
      console.error(`❌ ERROR: Private key di .env harusnya 64 karakter, tapi panjangnya cuma ${privateKey.length}.`);
      process.exit(1);
  }

  const agent = new SeiAgentKit(`0x${privateKey}`);
  
  console.log("✅ Agent siap tempur!");
  console.log("------------------------------------------");
  
  try {
    console.log(`🧪 Menguji coba Degen Token Analyzer untuk token: ${SEIYAN_CONTRACT_ADDRESS}`);
    const report = await analyzeToken(agent, SEIYAN_CONTRACT_ADDRESS);

    console.log("\n--- DEGEN REPORT DARI SEI-SAGE ---");
    console.log(report);
    console.log("------------------------------------------");

  } catch (err) {
    console.error("💀 GAGAL TOTAL SAAT UJI COBA:", err);
  }
}

main();